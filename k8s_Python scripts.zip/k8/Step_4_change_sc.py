#README
#
import paramiko
import time
import re
username = "administrator"
password = "emclegato"
storageClass_name = "sc-common"
directory = "/home/administrator/automation"


fh = open('kmasters.txt')
for f in fh:
    host = f.rstrip()
    print("\033[1m" + host + "\033[0m")

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, username=username, password=password)


    def execommand(thecommand):
        output = []
        stdina, stdouta, stderra = client.exec_command(thecommand)
        print(thecommand)
        for i in stdouta.readlines():
            print("{}".format(i))
            output.append(i)
        for i in stderra.readlines():
            print('\x1b[1;31m' + i + '\x1b[0m')
        return output
    def printOutPut(list):
        for i in list:
            print(i)
    print("Change SC name")
    # mkdir = "mkdir {}; wget --no-check-certificate ".format(directory)
    change_sc = "cd {};grep -rli 'sc-common' * | xargs -i@ sed -i 's/sc-common/{}/g' @".format(directory,storageClass_name)
    #create Storage class
    create_sc = "cd {}; kubectl apply -f global-storageclass.yml".format(directory)
    #Get strorage class
    get_storage_class = "cd {};kubectl get storageclass {}".format(directory,storageClass_name)
    # execommand(change_sc)
    execommand(create_sc)
    execommand(get_storage_class)
    # execommand("kubectl get nodes;kubectl get pods --namespace=kube-system")
    # execommand("cd /home/administrator/automation/; cat PostgreSQL-pvc.yaml;cat PostgreSQL-pvc.yaml;cat MySql-pvc.yaml;cat Mysql_Deployment.yaml")

    print("#############################################")
    client.close()
fh.close()